"""Reconstruct relevant native bridge classes; bytecode remains authoritative."""
from pathlib import Path
from loguru import logger
from androguard.core.dex import DEX
from androguard.core.analysis.analysis import Analysis
from androguard.decompiler.decompiler import DecompilerDAD

logger.remove()
root=Path(__file__).resolve().parent
out=root/'dex-analysis/java'
out.mkdir(parents=True,exist_ok=True)
dex=DEX((root.parents[1]/'accuniq-dashboard/classes.dex').read_bytes())
analysis=Analysis(dex)
compiler=DecompilerDAD(dex,analysis)
roots=('Lkr/co/bca/MainActivity;','Lcom/phonegap/plugins/barcodescanner/',
       'Lio/sqlc/','Lio/liteglue/SQLiteNDKNativeDriver;',
       'Lorg/apache/cordova/NativeToJsMessageQueue;','Lorg/apache/cordova/PluginManager;')
for cls in dex.get_classes():
    if any(cls.get_name().startswith(prefix) for prefix in roots):
        target=out/(cls.get_name()[1:-1]+'.java')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(compiler.get_source_class(cls),encoding='utf-8')
        print(target.relative_to(out))
