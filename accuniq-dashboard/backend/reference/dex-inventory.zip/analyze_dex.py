"""Reproducible full DEX inventory and instruction-level transport audit."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
import re
import zipfile
from loguru import logger
from androguard.core.dex import DEX

logger.remove()
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dex-analysis'
OUT.mkdir(exist_ok=True)
source=ROOT.parents[1]/'accuniq-dashboard/classes.dex'
raw=source.read_bytes()
with zipfile.ZipFile(ROOT/'base.apk') as archive:
    dex_entries=[n for n in archive.namelist() if re.fullmatch(r'classes\d*\.dex',n)]
    apk_match=any(raw==archive.read(n) for n in dex_entries)
dex=DEX(raw)
patterns={
    'bluetooth':r'Landroid/bluetooth/|BluetoothGatt|BluetoothSocket|connectGatt|createRfcomm|startDiscovery',
    'usb':r'Landroid/hardware/usb/|UsbSerial|UsbDeviceConnection|bulkTransfer|controlTransfer',
    'serial':r'Ljavax/comm/|Landroid_serialport|SerialPort|/dev/tty|baudrate',
    'network':r'Ljava/net/|Ljavax/net/|Lokhttp|Lorg/apache/http/',
    'camera_qr':r'Lcom/google/zxing/|Landroid/hardware/Camera|Lcom/phonegap/plugins/barcodescanner/',
    'sqlite':r'Landroid/database/sqlite/|Lio/liteglue/|Lio/sqlc/',
    'reflection':r'Ljava/lang/Class;->forName|Ljava/lang/reflect/|Ljava/lang/System;->loadLibrary',
}
classes=[]; methods=[]; calls=[]; hits=[]; strings=[]; counts=Counter()
with (OUT/'all-bytecode.txt').open('w',encoding='utf-8') as dump:
    for cls in dex.get_classes():
        name=cls.get_name()
        package=name[1:].rsplit('/',1)[0]
        counts[package]+=1
        classes.append(dict(name=name,superclass=cls.get_superclassname(),interfaces=';'.join(cls.get_interfaces()),method_count=len(cls.get_methods()),access=cls.get_access_flags_string()))
        dump.write('\nCLASS '+name+' EXTENDS '+cls.get_superclassname()+'\n')
        for field in cls.get_fields():
            dump.write('FIELD '+str(field)+'\n')
        for method in cls.get_methods():
            identity=f'{name}->{method.get_name()}{method.get_descriptor()}'
            code=method.get_code()
            methods.append(dict(class_name=name,name=method.get_name(),descriptor=method.get_descriptor(),access=method.get_access_flags_string(),has_code=bool(code)))
            dump.write('\nMETHOD '+identity+' '+method.get_access_flags_string()+'\n')
            if not code: continue
            offset=0
            for ins in method.get_instructions():
                text=ins.get_output()
                row=dict(caller=identity,offset=hex(offset),opcode=ins.get_name(),instruction=text)
                dump.write(f'{offset:06x} {ins.get_name()} {text}\n')
                if ins.get_name().startswith('invoke-'):calls.append(row)
                for category,pattern in patterns.items():
                    if re.search(pattern,text,re.I):hits.append(dict(category=category,**row))
                offset+=ins.get_length()
for index,string in enumerate(dex.get_strings()):
    value=str(string)
    strings.append(dict(index=index,value=value))
def save_csv(name,rows,fields):
    with (OUT/name).open('w',newline='',encoding='utf-8-sig') as file:
        writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader();writer.writerows(rows)
save_csv('classes.csv',classes,['name','superclass','interfaces','method_count','access'])
save_csv('methods.csv',methods,['class_name','name','descriptor','access','has_code'])
save_csv('calls.csv',calls,['caller','offset','opcode','instruction'])
save_csv('evidence.csv',hits,['category','caller','offset','opcode','instruction'])
save_csv('strings.csv',strings,['index','value'])
save_csv('packages.csv',[dict(package=k,classes=v) for k,v in counts.most_common()],['package','classes'])
summary=dict(sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),matches_apk=apk_match,apk_dex_entries=dex_entries,
             class_count=len(classes),defined_methods=len(methods),method_references=len(dex.get_methods()),
             invoke_instructions=len(calls),string_count=len(strings),categories=dict(Counter(h['category'] for h in hits)),
             hardware_evidence=[h for h in hits if h['category'] in ('bluetooth','usb','serial')],
             native_methods=[m for m in methods if 'native' in m['access']],
             hardware_strings=[s for s in strings if re.search(r'bluetooth|rfcomm|gatt|baud|/dev/tty|usbserial',s['value'],re.I)])
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('native_methods','hardware_strings','hardware_evidence')},indent=2))
print('Hardware instruction evidence:',summary['hardware_evidence'])
print('Hardware strings:',summary['hardware_strings'])
