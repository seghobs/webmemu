package com.phonegap.plugins.barcodescanner;
 class BarcodeScanner$1 implements java.lang.Runnable {
    final synthetic com.phonegap.plugins.barcodescanner.BarcodeScanner this$0;
    final synthetic org.json.JSONArray val$args;
    final synthetic org.apache.cordova.CordovaPlugin val$that;

    BarcodeScanner$1(com.phonegap.plugins.barcodescanner.BarcodeScanner p1, org.apache.cordova.CordovaPlugin p2, org.json.JSONArray p3)
    {
        this.this$0 = p1;
        this.val$that = p2;
        this.val$args = p3;
        return;
    }

    public void run()
    {
        android.content.Intent v1_1 = new android.content.Intent(this.val$that.cordova.getActivity().getBaseContext(), com.google.zxing.client.android.CaptureActivity);
        v1_1.setAction("com.google.zxing.client.android.SCAN");
        v1_1.addCategory("android.intent.category.DEFAULT");
        if (this.val$args.length() > 0) {
            int v3_0 = 0;
            while (v3_0 < this.val$args.length()) {
                try {
                    String v4_4 = this.val$args.getJSONObject(v3_0);
                    String v5_5 = v4_4.names();
                    boolean v6_5 = 0;
                } catch (String v4_5) {
                    android.util.Log.i("CordovaLog", v4_5.getLocalizedMessage());
                    v3_0++;
                }
                while (v6_5 < v5_5.length()) {
                    try {
                        long v7_0 = v5_5.getString(v6_5);
                        String v8_0 = v4_4.get(v7_0);
                    } catch (long v7_1) {
                        android.util.Log.i("CordovaLog", v7_1.getLocalizedMessage());
                        v6_5++;
                    }
                    if (!(v8_0 instanceof Integer)) {
                        if (!(v8_0 instanceof String)) {
                        } else {
                            v1_1.putExtra(v7_0, ((String) v8_0));
                        }
                    } else {
                        v1_1.putExtra(v7_0, ((Integer) v8_0));
                    }
                }
                v1_1.putExtra("SCAN_CAMERA_ID", v4_4.optBoolean("preferFrontCamera", 0));
                v1_1.putExtra("SHOW_FLIP_CAMERA_BUTTON", v4_4.optBoolean("showFlipCameraButton", 0));
                v1_1.putExtra("SHOW_TORCH_BUTTON", v4_4.optBoolean("showTorchButton", 0));
                v1_1.putExtra("TORCH_ON", v4_4.optBoolean("torchOn", 0));
                v1_1.putExtra("SAVE_HISTORY", v4_4.optBoolean("saveHistory", 0));
                v1_1.putExtra("BEEP_ON_SCAN", (v4_4.optBoolean("disableSuccessBeep", 0) ^ 1));
                if (v4_4.has("resultDisplayDuration")) {
                    boolean v6_14 = new StringBuilder();
                    v6_14.append("");
                    v6_14.append(v4_4.optLong("resultDisplayDuration"));
                    v1_1.putExtra("RESULT_DISPLAY_DURATION_MS", v6_14.toString());
                }
                if (v4_4.has("formats")) {
                    v1_1.putExtra("SCAN_FORMATS", v4_4.optString("formats"));
                }
                if (v4_4.has("prompt")) {
                    v1_1.putExtra("PROMPT_MESSAGE", v4_4.optString("prompt"));
                }
                if (!v4_4.has("orientation")) {
                } else {
                    v1_1.putExtra("ORIENTATION_LOCK", v4_4.optString("orientation"));
                }
            }
        }
        v1_1.setPackage(this.val$that.cordova.getActivity().getApplicationContext().getPackageName());
        this.val$that.cordova.startActivityForResult(this.val$that, v1_1, 47740);
        return;
    }
}
