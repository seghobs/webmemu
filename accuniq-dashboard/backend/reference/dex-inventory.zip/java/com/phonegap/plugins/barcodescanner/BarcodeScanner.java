package com.phonegap.plugins.barcodescanner;
public class BarcodeScanner extends org.apache.cordova.CordovaPlugin {
    private static final String CANCELLED = "cancelled";
    private static final String DATA = "data";
    private static final String DISABLE_BEEP = "disableSuccessBeep";
    private static final String EMAIL_TYPE = "EMAIL_TYPE";
    private static final String ENCODE = "encode";
    private static final String FORMAT = "format";
    private static final String FORMATS = "formats";
    private static final String LOG_TAG = "BarcodeScanner";
    private static final String ORIENTATION = "orientation";
    private static final String PHONE_TYPE = "PHONE_TYPE";
    private static final String PREFER_FRONTCAMERA = "preferFrontCamera";
    private static final String PROMPT = "prompt";
    public static final int REQUEST_CODE = 47740;
    private static final String RESULTDISPLAY_DURATION = "resultDisplayDuration";
    private static final String SAVE_HISTORY = "saveHistory";
    private static final String SCAN = "scan";
    private static final String SHOW_FLIP_CAMERA_BUTTON = "showFlipCameraButton";
    private static final String SHOW_TORCH_BUTTON = "showTorchButton";
    private static final String SMS_TYPE = "SMS_TYPE";
    private static final String TEXT = "text";
    private static final String TEXT_TYPE = "TEXT_TYPE";
    private static final String TORCH_ON = "torchOn";
    private static final String TYPE = "type";
    private org.apache.cordova.CallbackContext callbackContext;
    private String[] permissions;
    private org.json.JSONArray requestArgs;

    public BarcodeScanner()
    {
        String[] v0_1 = new String[1];
        v0_1[0] = "android.permission.CAMERA";
        this.permissions = v0_1;
        return;
    }

    public void encode(String p4, String p5)
    {
        android.content.Intent v0_1 = new android.content.Intent(this.cordova.getActivity().getBaseContext(), com.google.zxing.client.android.encode.EncodeActivity);
        v0_1.setAction("com.google.zxing.client.android.ENCODE");
        v0_1.putExtra("ENCODE_TYPE", p4);
        v0_1.putExtra("ENCODE_DATA", p5);
        v0_1.setPackage(this.cordova.getActivity().getApplicationContext().getPackageName());
        this.cordova.getActivity().startActivity(v0_1);
        return;
    }

    public boolean execute(String p4, org.json.JSONArray p5, org.apache.cordova.CallbackContext p6)
    {
        this.callbackContext = p6;
        this.requestArgs = p5;
        if (!p4.equals("encode")) {
            if (!p4.equals("scan")) {
                return 0;
            } else {
                if (this.hasPermisssion()) {
                    this.scan(p5);
                } else {
                    this.requestPermissions(0);
                }
            }
        } else {
            boolean v4_3 = p5.optJSONObject(0);
            if (!v4_3) {
                p6.error("User did not specify data to encode");
                return 1;
            } else {
                String v0_2 = v4_3.optString("type");
                boolean v4_4 = v4_3.optString("data");
                if (v0_2 == null) {
                    v0_2 = "TEXT_TYPE";
                }
                if (v4_4) {
                    this.encode(v0_2, v4_4);
                } else {
                    p6.error("User did not specify data to encode");
                    return 1;
                }
            }
        }
        return 1;
    }

    public boolean hasPermisssion()
    {
        int v0_0 = this.permissions;
        int v3 = 0;
        while (v3 < v0_0.length) {
            if (org.apache.cordova.PermissionHelper.hasPermission(this, v0_0[v3])) {
                v3++;
            } else {
                return 0;
            }
        }
        return 1;
    }

    public void onActivityResult(int p8, int p9, android.content.Intent p10)
    {
        if (p8 == 47740) {
            org.json.JSONObject v8_5 = this.callbackContext;
            if (v8_5 != null) {
                if (p9 != -1) {
                    if (p9 != null) {
                        v8_5.error("Unexpected error");
                    } else {
                        org.json.JSONObject v8_2 = new org.json.JSONObject();
                        try {
                            v8_2.put("text", "");
                            v8_2.put("format", "");
                            v8_2.put("cancelled", 1);
                        } catch (org.json.JSONException) {
                            android.util.Log.d("BarcodeScanner", "This should never happen");
                        }
                        this.callbackContext.success(v8_2);
                    }
                } else {
                    org.json.JSONObject v8_4 = new org.json.JSONObject();
                    try {
                        v8_4.put("text", p10.getStringExtra("SCAN_RESULT"));
                        v8_4.put("format", p10.getStringExtra("SCAN_RESULT_FORMAT"));
                        v8_4.put("cancelled", 0);
                    } catch (org.json.JSONException) {
                        android.util.Log.d("BarcodeScanner", "This should never happen");
                    }
                    this.callbackContext.success(v8_4);
                }
            }
        }
        return;
    }

    public void onRequestPermissionResult(int p4, String[] p5, int[] p6)
    {
        int v0 = 0;
        while (v0 < p6.length) {
            if (p6[v0] != -1) {
                v0++;
            } else {
                android.util.Log.d("BarcodeScanner", "Permission Denied!");
                this.callbackContext.sendPluginResult(new org.apache.cordova.PluginResult(org.apache.cordova.PluginResult$Status.ILLEGAL_ACCESS_EXCEPTION));
                return;
            }
        }
        if (p4 == null) {
            this.scan(this.requestArgs);
        }
        return;
    }

    public void onRestoreStateForActivityResult(android.os.Bundle p1, org.apache.cordova.CallbackContext p2)
    {
        this.callbackContext = p2;
        return;
    }

    public void requestPermissions(int p2)
    {
        org.apache.cordova.PermissionHelper.requestPermissions(this, p2, this.permissions);
        return;
    }

    public void scan(org.json.JSONArray p3)
    {
        this.cordova.getThreadPool().execute(new com.phonegap.plugins.barcodescanner.BarcodeScanner$1(this, this, p3));
        return;
    }
}
