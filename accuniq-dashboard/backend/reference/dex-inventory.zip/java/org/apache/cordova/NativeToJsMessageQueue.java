package org.apache.cordova;
public class NativeToJsMessageQueue {
    private static int COMBINED_RESPONSE_CUTOFF = 16777216;
    static final boolean DISABLE_EXEC_CHAINING = False;
    private static final boolean FORCE_ENCODE_USING_EVAL = False;
    private static final String LOG_TAG = "JsMessageQueue";
    private org.apache.cordova.NativeToJsMessageQueue$BridgeMode activeBridgeMode;
    private java.util.ArrayList bridgeModes;
    private boolean paused;
    private final java.util.LinkedList queue;

    static NativeToJsMessageQueue()
    {
        return;
    }

    public NativeToJsMessageQueue()
    {
        this.queue = new java.util.LinkedList();
        this.bridgeModes = new java.util.ArrayList();
        return;
    }

    private int calculatePackedMessageLength(org.apache.cordova.NativeToJsMessageQueue$JsMessage p2)
    {
        int v2_1 = p2.calculateEncodedLength();
        return ((String.valueOf(v2_1).length() + v2_1) + 1);
    }

    private void enqueueMessage(org.apache.cordova.NativeToJsMessageQueue$JsMessage p2)
    {
        try {
            if (this.activeBridgeMode != null) {
                this.queue.add(p2);
                if (!this.paused) {
                    this.activeBridgeMode.onNativeToJsMessageAvailable(this);
                }
                return;
            } else {
                org.apache.cordova.LOG.d("JsMessageQueue", "Dropping Native->JS message due to disabled bridge");
                return;
            }
        } catch (org.apache.cordova.NativeToJsMessageQueue$BridgeMode v2_1) {
            throw v2_1;
        }
    }

    private void packMessage(org.apache.cordova.NativeToJsMessageQueue$JsMessage p2, StringBuilder p3)
    {
        p3.append(p2.calculateEncodedLength());
        p3.append(32);
        p2.encodeAsMessage(p3);
        return;
    }

    public void addBridgeMode(org.apache.cordova.NativeToJsMessageQueue$BridgeMode p2)
    {
        this.bridgeModes.add(p2);
        return;
    }

    public void addJavaScript(String p2)
    {
        this.enqueueMessage(new org.apache.cordova.NativeToJsMessageQueue$JsMessage(p2));
        return;
    }

    public void addPluginResult(org.apache.cordova.PluginResult p3, String p4)
    {
        if (p4 != null) {
            org.apache.cordova.NativeToJsMessageQueue$JsMessage v0_4;
            if (p3.getStatus() != org.apache.cordova.PluginResult$Status.NO_RESULT.ordinal()) {
                v0_4 = 0;
            } else {
                v0_4 = 1;
            }
            boolean v1_0 = p3.getKeepCallback();
            if ((v0_4 == null) || (!v1_0)) {
                this.enqueueMessage(new org.apache.cordova.NativeToJsMessageQueue$JsMessage(p3, p4));
                return;
            } else {
                return;
            }
        } else {
            org.apache.cordova.LOG.e("JsMessageQueue", "Got plugin result with no callbackId", new Throwable());
            return;
        }
    }

    public boolean isBridgeEnabled()
    {
        int v0_1;
        if (this.activeBridgeMode == null) {
            v0_1 = 0;
        } else {
            v0_1 = 1;
        }
        return v0_1;
    }

    public boolean isEmpty()
    {
        return this.queue.isEmpty();
    }

    public String popAndEncode(boolean p7)
    {
        try {
            int v0_0 = this.activeBridgeMode;
        } catch (String v7_6) {
            throw v7_6;
        }
        if (v0_0 != 0) {
            v0_0.notifyOfFlush(this, p7);
            if (!this.queue.isEmpty()) {
                String v7_1 = this.queue.iterator();
                int v0_1 = 0;
                int v1_1 = 0;
                org.apache.cordova.NativeToJsMessageQueue$JsMessage v2_0 = 0;
                while (v7_1.hasNext()) {
                    int v3_3 = this.calculatePackedMessageLength(((org.apache.cordova.NativeToJsMessageQueue$JsMessage) v7_1.next()));
                    if (v1_1 > 0) {
                        int v4 = org.apache.cordova.NativeToJsMessageQueue.COMBINED_RESPONSE_CUTOFF;
                        if ((v4 > 0) && ((v2_0 + v3_3) > v4)) {
                            break;
                        }
                    }
                    v2_0 += v3_3;
                    v1_1++;
                }
                String v7_3 = new StringBuilder(v2_0);
                while (v0_1 < v1_1) {
                    this.packMessage(((org.apache.cordova.NativeToJsMessageQueue$JsMessage) this.queue.removeFirst()), v7_3);
                    v0_1++;
                }
                if (!this.queue.isEmpty()) {
                    v7_3.append(42);
                }
                return v7_3.toString();
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public String popAndEncodeAsJs()
    {
        try {
            if (this.queue.size() != 0) {
                String v0_7 = this.queue.iterator();
                int v1_2 = 0;
                int v2 = 0;
                String v3_0 = 0;
                while (v0_7.hasNext()) {
                    StringBuilder v4_4 = (((org.apache.cordova.NativeToJsMessageQueue$JsMessage) v0_7.next()).calculateEncodedLength() + 50);
                    if (v2 > 0) {
                        String v5_0 = org.apache.cordova.NativeToJsMessageQueue.COMBINED_RESPONSE_CUTOFF;
                        if ((v5_0 > null) && ((v3_0 + v4_4) > v5_0)) {
                            break;
                        }
                    }
                    v3_0 += v4_4;
                    v2++;
                }
                String v0_4;
                if (v2 != this.queue.size()) {
                    v0_4 = 0;
                } else {
                    v0_4 = 1;
                }
                String v5_1;
                if (v0_4 == null) {
                    v5_1 = 100;
                } else {
                    v5_1 = 0;
                }
                StringBuilder v4_6 = new StringBuilder((v3_0 + v5_1));
                while (v1_2 < v2) {
                    String v3_4 = ((org.apache.cordova.NativeToJsMessageQueue$JsMessage) this.queue.removeFirst());
                    if ((v0_4 == null) || ((v1_2 + 1) != v2)) {
                        v4_6.append("try{");
                        v3_4.encodeAsJsMessage(v4_6);
                        v4_6.append("}finally{");
                    } else {
                        v3_4.encodeAsJsMessage(v4_6);
                    }
                    v1_2++;
                }
                if (v0_4 == null) {
                    v4_6.append("window.setTimeout(function(){cordova.require(\'cordova/plugin/android/polling\').pollOnce();},0);");
                }
                while (v0_4 < v2) {
                    v4_6.append(125);
                    v0_4++;
                }
                return v4_6.toString();
            } else {
                return 0;
            }
        } catch (String v0_9) {
            throw v0_9;
        }
    }

    public void reset()
    {
        try {
            this.queue.clear();
            this.setBridgeMode(-1);
            return;
        } catch (Throwable v0_2) {
            throw v0_2;
        }
    }

    public void setBridgeMode(int p4)
    {
        if ((p4 >= -1) && (p4 < this.bridgeModes.size())) {
            Throwable v4_1;
            if (p4 >= null) {
                v4_1 = ((org.apache.cordova.NativeToJsMessageQueue$BridgeMode) this.bridgeModes.get(p4));
            } else {
                v4_1 = 0;
            }
            if (v4_1 != this.activeBridgeMode) {
                String v2_2;
                String v1_1 = new StringBuilder();
                v1_1.append("Set native->JS mode to ");
                if (v4_1 != null) {
                    v2_2 = v4_1.getClass().getSimpleName();
                } else {
                    v2_2 = "null";
                }
                v1_1.append(v2_2);
                org.apache.cordova.LOG.d("JsMessageQueue", v1_1.toString());
                try {
                    this.activeBridgeMode = v4_1;
                } catch (Throwable v4_2) {
                    throw v4_2;
                }
                if (v4_1 != null) {
                    v4_1.reset();
                    if ((!this.paused) && (!this.queue.isEmpty())) {
                        v4_1.onNativeToJsMessageAvailable(this);
                    }
                }
            }
        } else {
            String v1_4 = new StringBuilder();
            v1_4.append("Invalid NativeToJsBridgeMode: ");
            v1_4.append(p4);
            org.apache.cordova.LOG.d("JsMessageQueue", v1_4.toString());
        }
        return;
    }

    public void setPaused(boolean p4)
    {
        if ((this.paused) && (p4 != null)) {
            org.apache.cordova.LOG.e("JsMessageQueue", "nested call to setPaused detected.", new Throwable());
        }
        this.paused = p4;
        if (p4 == null) {
            try {
                if (!this.queue.isEmpty()) {
                    org.apache.cordova.NativeToJsMessageQueue$BridgeMode v4_3 = this.activeBridgeMode;
                    if (v4_3 != null) {
                        v4_3.onNativeToJsMessageAvailable(this);
                    }
                }
            } catch (org.apache.cordova.NativeToJsMessageQueue$BridgeMode v4_4) {
                throw v4_4;
            }
        }
        return;
    }
}
