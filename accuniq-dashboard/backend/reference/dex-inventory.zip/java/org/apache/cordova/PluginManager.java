package org.apache.cordova;
public class PluginManager {
    private static String DEFAULT_HOSTNAME = "localhost";
    private static String SCHEME_HTTPS = "https";
    private static final int SLOW_EXEC_WARNING_THRESHOLD = 0;
    private static String TAG = "PluginManager";
    private final org.apache.cordova.CordovaWebView app;
    private final org.apache.cordova.CordovaInterface ctx;
    private final java.util.Map entryMap;
    private boolean isInitialized;
    private org.apache.cordova.CordovaPlugin permissionRequester;
    private final java.util.Map pluginMap;

    static PluginManager()
    {
        int v0_1;
        if (!android.os.Debug.isDebuggerConnected()) {
            v0_1 = 16;
        } else {
            v0_1 = 60;
        }
        org.apache.cordova.PluginManager.SLOW_EXEC_WARNING_THRESHOLD = v0_1;
        return;
    }

    public PluginManager(org.apache.cordova.CordovaWebView p2, org.apache.cordova.CordovaInterface p3, java.util.Collection p4)
    {
        this.pluginMap = java.util.Collections.synchronizedMap(new java.util.LinkedHashMap());
        this.entryMap = java.util.Collections.synchronizedMap(new java.util.LinkedHashMap());
        this.ctx = p3;
        this.app = p2;
        this.setPluginEntries(p4);
        return;
    }

    private String getLaunchUrlPrefix()
    {
        if (this.app.getPreferences().getBoolean("AndroidInsecureFileModeEnabled", 0)) {
            return "file://";
        } else {
            String v0_4 = this.app.getPreferences().getString("scheme", org.apache.cordova.PluginManager.SCHEME_HTTPS).toLowerCase();
            String v1_3 = this.app.getPreferences().getString("hostname", org.apache.cordova.PluginManager.DEFAULT_HOSTNAME);
            StringBuilder v2_3 = new StringBuilder();
            v2_3.append(v0_4);
            v2_3.append("://");
            v2_3.append(v1_3);
            v2_3.append(47);
            return v2_3.toString();
        }
    }

    private org.apache.cordova.CordovaPlugin instantiatePlugin(String p5)
    {
        org.apache.cordova.CordovaPlugin v1_6;
        org.apache.cordova.CordovaPlugin v0 = 0;
        if ((p5 == null) || ("".equals(p5))) {
            v1_6 = 0;
            int v2_0;
            if (v1_6 == null) {
                v2_0 = 0;
            } else {
                v2_0 = 1;
            }
            if ((v2_0 & org.apache.cordova.CordovaPlugin.isAssignableFrom(v1_6)) != 0) {
                v0 = ((org.apache.cordova.CordovaPlugin) v1_6.newInstance());
            }
        } else {
            v1_6 = Class.forName(p5);
        }
        return v0;
    }

    static synthetic void lambda$postMessage$0(String p0, Object p1, String p2, org.apache.cordova.CordovaPlugin p3)
    {
        if (p3 != null) {
            p3.onMessage(p0, p1);
        }
        return;
    }

    private void startupPlugins()
    {
        try {
            Throwable v1_3 = this.entryMap.values().iterator();
        } catch (Throwable v1_2) {
            throw v1_2;
        }
        while (v1_3.hasNext()) {
            String v2_1 = ((org.apache.cordova.PluginEntry) v1_3.next());
            if (!v2_1.onload) {
                int v4_1 = new StringBuilder();
                v4_1.append("startupPlugins: put - ");
                v4_1.append(v2_1.service);
                org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, v4_1.toString());
                this.pluginMap.put(v2_1.service, 0);
            } else {
                this.getPlugin(v2_1.service);
            }
        }
        return;
    }

    public void addService(String p3, String p4)
    {
        this.addService(new org.apache.cordova.PluginEntry(p3, p4, 0));
        return;
    }

    public void addService(org.apache.cordova.PluginEntry p6)
    {
        this.entryMap.put(p6.service, p6);
        if (p6.plugin != null) {
            org.apache.cordova.CordovaWebView v3 = this.app;
            p6.plugin.privateInitialize(p6.service, this.ctx, v3, v3.getPreferences());
            String v1_2 = new StringBuilder();
            v1_2.append("addService: put - ");
            v1_2.append(p6.service);
            org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, v1_2.toString());
            this.pluginMap.put(p6.service, p6.plugin);
        }
        return;
    }

    public void exec(String p7, String p8, String p9, String p10)
    {
        StringBuilder v0_0 = this.getPlugin(p7);
        if (v0_0 != null) {
            org.apache.cordova.CallbackContext v1_1 = new org.apache.cordova.CallbackContext(p9, this.app);
            try {
                String v2_3 = System.currentTimeMillis();
                String v9_2 = v0_0.execute(p8, p10, v1_1);
                long v4_1 = (System.currentTimeMillis() - v2_3);
            } catch (org.json.JSONException) {
                v1_1.sendPluginResult(new org.apache.cordova.PluginResult(org.apache.cordova.PluginResult$Status.JSON_EXCEPTION));
                return;
            } catch (org.apache.cordova.PluginResult v7_5) {
                org.apache.cordova.LOG.e(org.apache.cordova.PluginManager.TAG, "Uncaught exception from plugin", v7_5);
                v1_1.error(v7_5.getMessage());
                return;
            }
            if (v4_1 > ((long) org.apache.cordova.PluginManager.SLOW_EXEC_WARNING_THRESHOLD)) {
                StringBuilder v0_2 = new StringBuilder();
                v0_2.append("THREAD WARNING: exec() call to ");
                v0_2.append(p7);
                v0_2.append(".");
                v0_2.append(p8);
                v0_2.append(" blocked the main thread for ");
                v0_2.append(v4_1);
                v0_2.append("ms. Plugin should use CordovaInterface.getThreadPool().");
                org.apache.cordova.LOG.w(org.apache.cordova.PluginManager.TAG, v0_2.toString());
            }
            if (v9_2 != null) {
                return;
            } else {
                v1_1.sendPluginResult(new org.apache.cordova.PluginResult(org.apache.cordova.PluginResult$Status.INVALID_ACTION));
                return;
            }
        } else {
            String v10_5 = new StringBuilder();
            v10_5.append("exec() call to unknown plugin: ");
            v10_5.append(p7);
            org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, v10_5.toString());
            this.app.sendPluginResult(new org.apache.cordova.PluginResult(org.apache.cordova.PluginResult$Status.CLASS_NOT_FOUND_EXCEPTION), p9);
            return;
        }
    }

    public org.apache.cordova.CordovaPlugin getPlugin(String p5)
    {
        org.apache.cordova.CordovaPlugin v0_2 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(p5));
        if (v0_2 == null) {
            org.apache.cordova.CordovaPlugin v0_6 = ((org.apache.cordova.PluginEntry) this.entryMap.get(p5));
            if (v0_6 != null) {
                if (v0_6.plugin == null) {
                    v0_2 = this.instantiatePlugin(v0_6.pluginClass);
                } else {
                    v0_2 = v0_6.plugin;
                }
                String v2_0 = this.app;
                v0_2.privateInitialize(p5, this.ctx, v2_0, v2_0.getPreferences());
                String v2_2 = new StringBuilder();
                v2_2.append("getPlugin - put: ");
                v2_2.append(p5);
                org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, v2_2.toString());
                this.pluginMap.put(p5, v0_2);
            } else {
                return 0;
            }
        }
        return v0_2;
    }

    public java.util.Collection getPluginEntries()
    {
        return this.entryMap.values();
    }

    public java.util.ArrayList getPluginPathHandlers()
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        while (v1_2.hasNext()) {
            org.apache.cordova.CordovaPluginPathHandler v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if ((v2_1 != null) && (v2_1.getPathHandler() != null)) {
                v0_1.add(v2_1.getPathHandler());
            }
        }
        return v0_1;
    }

    public void init()
    {
        org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, "init()");
        this.isInitialized = 1;
        this.onPause(0);
        this.onDestroy();
        this.pluginMap.clear();
        this.startupPlugins();
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p4)
    {
        try {
            java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        } catch (Throwable v4_1) {
            throw v4_1;
        }
        while (v1_2.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if (v2_1 != null) {
                v2_1.onConfigurationChanged(p4);
            }
        }
        return;
    }

    public void onDestroy()
    {
        try {
            Throwable v1_3 = this.pluginMap.values().iterator();
        } catch (Throwable v1_1) {
            throw v1_1;
        }
        while (v1_3.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_3.next());
            if (v2_1 != null) {
                v2_1.onDestroy();
            }
        }
        return;
    }

    public void onNewIntent(android.content.Intent p4)
    {
        try {
            java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        } catch (Throwable v4_1) {
            throw v4_1;
        }
        while (v1_2.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if (v2_1 != null) {
                v2_1.onNewIntent(p4);
            }
        }
        return;
    }

    public boolean onOverrideUrlLoading(String p5)
    {
        try {
            java.util.Iterator v1_2 = this.entryMap.values().iterator();
        } catch (int v5_2) {
            throw v5_2;
        }
        while (v1_2.hasNext()) {
            boolean v2_4 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(((org.apache.cordova.PluginEntry) v1_2.next()).service));
            if ((v2_4) && (v2_4.onOverrideUrlLoading(p5))) {
                return 1;
            }
        }
        return 0;
    }

    public void onPause(boolean p4)
    {
        try {
            java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        } catch (Throwable v4_1) {
            throw v4_1;
        }
        while (v1_2.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if (v2_1 != null) {
                v2_1.onPause(p4);
            }
        }
        return;
    }

    public boolean onReceivedClientCertRequest(org.apache.cordova.CordovaWebView p4, org.apache.cordova.ICordovaClientCertRequest p5)
    {
        try {
            java.util.Iterator v0_2 = this.pluginMap.values().iterator();
        } catch (int v5_2) {
            throw v5_2;
        }
        while (v0_2.hasNext()) {
            boolean v1_1 = ((org.apache.cordova.CordovaPlugin) v0_2.next());
            if ((v1_1) && (v1_1.onReceivedClientCertRequest(this.app, p5))) {
                return 1;
            }
        }
        return 0;
    }

    public boolean onReceivedHttpAuthRequest(org.apache.cordova.CordovaWebView p4, org.apache.cordova.ICordovaHttpAuthHandler p5, String p6, String p7)
    {
        try {
            java.util.Iterator v0_2 = this.pluginMap.values().iterator();
        } catch (int v5_2) {
            throw v5_2;
        }
        while (v0_2.hasNext()) {
            boolean v1_1 = ((org.apache.cordova.CordovaPlugin) v0_2.next());
            if ((v1_1) && (v1_1.onReceivedHttpAuthRequest(this.app, p5, p6, p7))) {
                return 1;
            }
        }
        return 0;
    }

    public void onReset()
    {
        try {
            Throwable v1_3 = this.pluginMap.values().iterator();
        } catch (Throwable v1_1) {
            throw v1_1;
        }
        while (v1_3.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_3.next());
            if (v2_1 != null) {
                v2_1.onReset();
            }
        }
        return;
    }

    public void onResume(boolean p4)
    {
        try {
            java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        } catch (Throwable v4_1) {
            throw v4_1;
        }
        while (v1_2.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if (v2_1 != null) {
                v2_1.onResume(p4);
            }
        }
        return;
    }

    public android.os.Bundle onSaveInstanceState()
    {
        Throwable v0_1 = new android.os.Bundle();
        try {
            java.util.Iterator v2_2 = this.pluginMap.values().iterator();
        } catch (Throwable v0_2) {
            throw v0_2;
        }
        while (v2_2.hasNext()) {
            String v3_1 = ((org.apache.cordova.CordovaPlugin) v2_2.next());
            if (v3_1 != null) {
                android.os.Bundle v4 = v3_1.onSaveInstanceState();
                if (v4 != null) {
                    v0_1.putBundle(v3_1.getServiceName(), v4);
                }
            }
        }
        return v0_1;
    }

    public void onStart()
    {
        try {
            Throwable v1_3 = this.pluginMap.values().iterator();
        } catch (Throwable v1_1) {
            throw v1_1;
        }
        while (v1_3.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_3.next());
            if (v2_1 != null) {
                v2_1.onStart();
            }
        }
        return;
    }

    public void onStop()
    {
        try {
            Throwable v1_3 = this.pluginMap.values().iterator();
        } catch (Throwable v1_1) {
            throw v1_1;
        }
        while (v1_3.hasNext()) {
            org.apache.cordova.CordovaPlugin v2_1 = ((org.apache.cordova.CordovaPlugin) v1_3.next());
            if (v2_1 != null) {
                v2_1.onStop();
            }
        }
        return;
    }

    public Object postMessage(String p4, Object p5)
    {
        java.util.Iterator v1_5 = new StringBuilder();
        v1_5.append("postMessage: ");
        v1_5.append(p4);
        org.apache.cordova.LOG.d(org.apache.cordova.PluginManager.TAG, v1_5.toString());
        if (android.os.Build$VERSION.SDK_INT < 24) {
            java.util.Iterator v1_4 = this.pluginMap.values().iterator();
            while (v1_4.hasNext()) {
                Object v2_3 = ((org.apache.cordova.CordovaPlugin) v1_4.next());
                if (v2_3 != null) {
                    Object v2_4 = v2_3.onMessage(p4, p5);
                    if (v2_4 != null) {
                        return v2_4;
                    }
                }
            }
        } else {
            this.pluginMap.forEach(new org.apache.cordova.-$$Lambda$PluginManager$kKlpZRFgWP16asRDDcqrOrVxJAs(p4, p5));
        }
        return this.ctx.onMessage(p4, p5);
    }

    android.net.Uri remapUri(android.net.Uri p4)
    {
        try {
            java.util.Iterator v1_2 = this.pluginMap.values().iterator();
        } catch (int v4_1) {
            throw v4_1;
        }
        while (v1_2.hasNext()) {
            android.net.Uri v2_1 = ((org.apache.cordova.CordovaPlugin) v1_2.next());
            if (v2_1 != null) {
                android.net.Uri v2_2 = v2_1.remapUri(p4);
                if (v2_2 != null) {
                    return v2_2;
                }
            }
        }
        return 0;
    }

    public void setPluginEntries(java.util.Collection p2)
    {
        if (this.isInitialized) {
            this.onPause(0);
            this.onDestroy();
            this.pluginMap.clear();
            this.entryMap.clear();
        }
        boolean v2_1 = p2.iterator();
        while (v2_1.hasNext()) {
            this.addService(((org.apache.cordova.PluginEntry) v2_1.next()));
        }
        if (this.isInitialized) {
            this.startupPlugins();
        }
        return;
    }

    public boolean shouldAllowBridgeAccess(String p5)
    {
        java.util.Iterator v1_2 = this.entryMap.values().iterator();
        while (v1_2.hasNext()) {
            Boolean v2_4 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(((org.apache.cordova.PluginEntry) v1_2.next()).service));
            if (v2_4 != null) {
                Boolean v2_5 = v2_4.shouldAllowBridgeAccess(p5);
                if (v2_5 != null) {
                    return v2_5.booleanValue();
                }
            }
        }
        return p5.startsWith(this.getLaunchUrlPrefix());
    }

    public boolean shouldAllowNavigation(String p5)
    {
        java.util.Iterator v1_2 = this.entryMap.values().iterator();
        while (v1_2.hasNext()) {
            Boolean v2_4 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(((org.apache.cordova.PluginEntry) v1_2.next()).service));
            if (v2_4 != null) {
                Boolean v2_5 = v2_4.shouldAllowNavigation(p5);
                if (v2_5 != null) {
                    return v2_5.booleanValue();
                }
            }
        }
        if ((!p5.startsWith(this.getLaunchUrlPrefix())) && (!p5.startsWith("about:blank"))) {
            int v5_2 = 0;
        } else {
            v5_2 = 1;
        }
        return v5_2;
    }

    public boolean shouldAllowRequest(String p5)
    {
        int v1_3 = this.entryMap.values().iterator();
        while (v1_3.hasNext()) {
            Boolean v2_4 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(((org.apache.cordova.PluginEntry) v1_3.next()).service));
            if (v2_4 != null) {
                Boolean v2_5 = v2_4.shouldAllowRequest(p5);
                if (v2_5 != null) {
                    return v2_5.booleanValue();
                }
            }
        }
        if ((!p5.startsWith("blob:")) && ((!p5.startsWith("data:")) && (!p5.startsWith("about:blank")))) {
            if (!p5.startsWith("https://ssl.gstatic.com/accessibility/javascript/android/")) {
                if (!p5.startsWith("file://")) {
                    return 0;
                } else {
                    return (p5.contains("/app_webview/") ^ 1);
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public Boolean shouldOpenExternalUrl(String p5)
    {
        java.util.Iterator v1_2 = this.entryMap.values().iterator();
        while (v1_2.hasNext()) {
            Boolean v2_4 = ((org.apache.cordova.CordovaPlugin) this.pluginMap.get(((org.apache.cordova.PluginEntry) v1_2.next()).service));
            if (v2_4 != null) {
                Boolean v2_5 = v2_4.shouldOpenExternalUrl(p5);
                if (v2_5 != null) {
                    return v2_5;
                }
            }
        }
        return Boolean.valueOf(0);
    }
}
