package io.sqlc;
 class SQLiteConnectorDatabase extends io.sqlc.SQLiteAndroidDatabase {
    static io.liteglue.SQLiteConnector connector;
    io.liteglue.SQLiteConnection mydb;

    static SQLiteConnectorDatabase()
    {
        io.sqlc.SQLiteConnectorDatabase.connector = new io.liteglue.SQLiteConnector();
        return;
    }

    SQLiteConnectorDatabase()
    {
        return;
    }

    private org.json.JSONObject executeSQLiteStatement(String p8, org.json.JSONArray p9, org.apache.cordova.CallbackContext p10)
    {
        String v1_2 = new org.json.JSONObject();
        io.liteglue.SQLiteStatement v8_1 = this.mydb.prepareStatement(p8);
        try {
            p9.length();
            StringBuilder v2 = 0;
            int v3_0 = 0;
        } catch (org.json.JSONException v9_6) {
            v9_6.printStackTrace();
            String v1_0 = v9_6.getMessage();
            StringBuilder v2_1 = new StringBuilder();
            v2_1.append("SQLitePlugin.executeSql[Batch](): Error=");
            v2_1.append(v1_0);
            android.util.Log.v("executeSqlBatch", v2_1.toString());
            v8_1.dispose();
            throw v9_6;
        } catch (org.json.JSONException v9_5) {
            v9_5.printStackTrace();
            String v1_3 = v9_5.getMessage();
            StringBuilder v2_5 = new StringBuilder();
            v2_5.append("SQLitePlugin.executeSql[Batch](): Error=");
            v2_5.append(v1_3);
            android.util.Log.v("executeSqlBatch", v2_5.toString());
            v8_1.dispose();
            throw v9_5;
        }
        while (v3_0 < p9.length()) {
            if (!p9.isNull(v3_0)) {
                String v4_3 = p9.get(v3_0);
                if (!(v4_3 instanceof Float)) {
                    if (!(v4_3 instanceof Double)) {
                        if (!(v4_3 instanceof Number)) {
                            v8_1.bindTextNativeString((v3_0 + 1), p9.getString(v3_0));
                            v3_0++;
                        } else {
                            v8_1.bindLong((v3_0 + 1), p9.getLong(v3_0));
                        }
                    } else {
                    }
                }
                v8_1.bindDouble((v3_0 + 1), p9.getDouble(v3_0));
            } else {
                v8_1.bindNull((v3_0 + 1));
            }
        }
        if (v8_1.step()) {
            org.json.JSONException v9_3 = new org.json.JSONArray();
            String v10_2 = v8_1.getColumnCount();
            while(true) {
                boolean v0_2 = new org.json.JSONObject();
                int v3_1 = 0;
                if (v3_1 >= v10_2) {
                    v9_3.put(v0_2);
                } else {
                    try {
                        String v4_1 = v8_1.getColumnName(v3_1);
                        Object v5_0 = v8_1.getColumnType(v3_1);
                    } catch (boolean v0_3) {
                        v0_3.printStackTrace();
                    }
                    if (v5_0 == 1) {
                        v0_2.put(v4_1, v8_1.getColumnLong(v3_1));
                    } else {
                        if (v5_0 == 2) {
                            v0_2.put(v4_1, v8_1.getColumnDouble(v3_1));
                        } else {
                            if (v5_0 == 5) {
                                v0_2.put(v4_1, org.json.JSONObject.NULL);
                            } else {
                                v0_2.put(v4_1, v8_1.getColumnTextNativeString(v3_1));
                            }
                        }
                    }
                    v3_1++;
                    while (v3_1 < v10_2) {
                    }
                }
                if (!v8_1.step()) {
                    try {
                        v1_2.put("rows", v9_3);
                    } catch (org.json.JSONException v9_4) {
                        v9_4.printStackTrace();
                    }
                }
            }
        }
        v8_1.dispose();
        return v1_2;
    }

    void bugWorkaround()
    {
        return;
    }

    void closeDatabaseNow()
    {
        try {
            Exception v0_0 = this.mydb;
        } catch (Exception v0_1) {
            android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t close database, ignoring", v0_1);
            return;
        }
        if (v0_0 == null) {
            return;
        } else {
            v0_0.dispose();
            return;
        }
    }

    void executeSqlBatch(String[] p12, org.json.JSONArray[] p13, org.apache.cordova.CallbackContext p14)
    {
        if (this.mydb != null) {
            int v1_1 = p12.length;
            org.json.JSONArray v2_1 = new org.json.JSONArray();
            int v4 = 0;
            while (v4 < v1_1) {
                try {
                    String v7_3 = ((long) this.mydb.getTotalChanges());
                    String v5_2 = this.executeSQLiteStatement(p12[v4], p13[v4], p14);
                    org.json.JSONObject v9_2 = (((long) this.mydb.getTotalChanges()) - v7_3);
                    v5_2.put("rowsAffected", v9_2);
                } catch (StringBuilder v6_8) {
                    v6_8.printStackTrace();
                    StringBuilder v6_9 = v6_8.getMessage();
                    String v7_5 = new StringBuilder();
                    v7_5.append("SQLitePlugin.executeSql[Batch](): UNEXPECTED JSON Error=");
                    v7_5.append(v6_9);
                    android.util.Log.e("executeSqlBatch", v7_5.toString());
                    String v7_8 = 0;
                    if (v5_2 == null) {
                        String v5_4 = new org.json.JSONObject();
                        v5_4.put("type", "error");
                        org.json.JSONObject v9_7 = new org.json.JSONObject();
                        v9_7.put("message", v6_9);
                        v9_7.put("code", v7_8);
                        v5_4.put("result", v9_7);
                        v2_1.put(v5_4);
                    } else {
                        try {
                            StringBuilder v6_13 = new org.json.JSONObject();
                            v6_13.put("type", "success");
                            v6_13.put("result", v5_2);
                            v2_1.put(v6_13);
                        } catch (String v5_5) {
                            v5_5.printStackTrace();
                            StringBuilder v6_1 = new StringBuilder();
                            v6_1.append("SQLitePlugin.executeSql[Batch](): Error=");
                            v6_1.append(v5_5.getMessage());
                            android.util.Log.e("executeSqlBatch", v6_1.toString());
                        }
                    }
                    v4++;
                } catch (StringBuilder v6_10) {
                    v6_10.printStackTrace();
                    String v7_7 = v6_10.getErrorCode();
                    v6_9 = v6_10.getMessage();
                    String v8_5 = new StringBuilder();
                    v8_5.append("SQLitePlugin.executeSql[Batch](): SQL Error code = ");
                    v8_5.append(v7_7);
                    v8_5.append(" message = ");
                    v8_5.append(v6_9);
                    android.util.Log.v("executeSqlBatch", v8_5.toString());
                    if (v7_7 == 1) {
                        v7_8 = 5;
                    } else {
                        if (v7_7 == 13) {
                            v7_8 = 4;
                        } else {
                            if (v7_7 == 19) {
                                v7_8 = 6;
                            }
                        }
                    }
                    v6_9 = "unknown";
                }
                if (v9_2 > 0) {
                    String v8_2 = this.mydb.getLastInsertRowid();
                    if (v8_2 > 0) {
                        v5_2.put("insertId", v8_2);
                    }
                }
            }
            p14.success(v2_1);
            return;
        } else {
            p14.error("database has been closed");
            return;
        }
    }

    void open(java.io.File p3)
    {
        this.mydb = io.sqlc.SQLiteConnectorDatabase.connector.newSQLiteConnection(p3.getAbsolutePath(), 6);
        return;
    }
}
