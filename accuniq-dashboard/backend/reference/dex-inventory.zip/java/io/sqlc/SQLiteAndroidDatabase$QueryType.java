package io.sqlc;
final enum class SQLiteAndroidDatabase$QueryType extends java.lang.Enum {
    private static final synthetic io.sqlc.SQLiteAndroidDatabase$QueryType[] $VALUES;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType begin;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType commit;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType delete;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType insert;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType other;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType rollback;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType select;
    public static final enum io.sqlc.SQLiteAndroidDatabase$QueryType update;

    static SQLiteAndroidDatabase$QueryType()
    {
        int v0_1 = new io.sqlc.SQLiteAndroidDatabase$QueryType("update", 0);
        io.sqlc.SQLiteAndroidDatabase$QueryType.update = v0_1;
        io.sqlc.SQLiteAndroidDatabase$QueryType v1_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("insert", 1);
        io.sqlc.SQLiteAndroidDatabase$QueryType.insert = v1_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType v3_1 = new io.sqlc.SQLiteAndroidDatabase$QueryType("delete", 2);
        io.sqlc.SQLiteAndroidDatabase$QueryType.delete = v3_1;
        io.sqlc.SQLiteAndroidDatabase$QueryType v5_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("select", 3);
        io.sqlc.SQLiteAndroidDatabase$QueryType.select = v5_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType v7_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("begin", 4);
        io.sqlc.SQLiteAndroidDatabase$QueryType.begin = v7_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType v9_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("commit", 5);
        io.sqlc.SQLiteAndroidDatabase$QueryType.commit = v9_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType v11_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("rollback", 6);
        io.sqlc.SQLiteAndroidDatabase$QueryType.rollback = v11_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType v13_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType("other", 7);
        io.sqlc.SQLiteAndroidDatabase$QueryType.other = v13_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType[] v15_2 = new io.sqlc.SQLiteAndroidDatabase$QueryType[8];
        v15_2[0] = v0_1;
        v15_2[1] = v1_2;
        v15_2[2] = v3_1;
        v15_2[3] = v5_2;
        v15_2[4] = v7_2;
        v15_2[5] = v9_2;
        v15_2[6] = v11_2;
        v15_2[7] = v13_2;
        io.sqlc.SQLiteAndroidDatabase$QueryType.$VALUES = v15_2;
        return;
    }

    private SQLiteAndroidDatabase$QueryType(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static io.sqlc.SQLiteAndroidDatabase$QueryType valueOf(String p1)
    {
        return ((io.sqlc.SQLiteAndroidDatabase$QueryType) Enum.valueOf(io.sqlc.SQLiteAndroidDatabase$QueryType, p1));
    }

    public static io.sqlc.SQLiteAndroidDatabase$QueryType[] values()
    {
        return ((io.sqlc.SQLiteAndroidDatabase$QueryType[]) io.sqlc.SQLiteAndroidDatabase$QueryType.$VALUES.clone());
    }
}
