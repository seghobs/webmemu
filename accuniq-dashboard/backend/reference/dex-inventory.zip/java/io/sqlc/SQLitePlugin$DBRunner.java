package io.sqlc;
 class SQLitePlugin$DBRunner implements java.lang.Runnable {
    private boolean bugWorkaround;
    final String dbname;
    io.sqlc.SQLiteAndroidDatabase mydb;
    private boolean oldImpl;
    final org.apache.cordova.CallbackContext openCbc;
    final java.util.concurrent.BlockingQueue q;
    final synthetic io.sqlc.SQLitePlugin this$0;

    SQLitePlugin$DBRunner(io.sqlc.SQLitePlugin p1, String p2, org.json.JSONObject p3, org.apache.cordova.CallbackContext p4)
    {
        java.util.concurrent.LinkedBlockingQueue v1_4;
        this.this$0 = p1;
        this.dbname = p2;
        this.oldImpl = p3.has("androidOldDatabaseImplementation");
        android.util.Log.v(io.sqlc.SQLitePlugin.getSimpleName(), "Android db implementation: built-in android.database.sqlite package");
        if ((!this.oldImpl) || (!p3.has("androidBugWorkaround"))) {
            v1_4 = 0;
        } else {
            v1_4 = 1;
        }
        this.bugWorkaround = v1_4;
        if (v1_4 != null) {
            android.util.Log.v(io.sqlc.SQLitePlugin.getSimpleName(), "Android db closing/locking workaround applied");
        }
        this.q = new java.util.concurrent.LinkedBlockingQueue();
        this.openCbc = p4;
        return;
    }

    public void run()
    {
        try {
            this.mydb = io.sqlc.SQLitePlugin.access$000(this.this$0, this.dbname, this.openCbc, this.oldImpl);
            org.apache.cordova.CallbackContext v1_4 = 0;
            try {
                String v2_2 = ((io.sqlc.SQLitePlugin$DBQuery) this.q.take());
            } catch (String v2_15) {
                android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "unexpected error", v2_15);
            }
            while(true) {
                v1_4 = v2_2;
                if (v1_4.stop) {
                    break;
                }
                this.mydb.executeSqlBatch(v1_4.queries, v1_4.jsonparams, v1_4.cbc);
                if ((this.bugWorkaround) && ((v1_4.queries.length == 1) && (v1_4.queries[0] == "COMMIT"))) {
                    this.mydb.bugWorkaround();
                }
                v2_2 = ((io.sqlc.SQLitePlugin$DBQuery) this.q.take());
            }
            if ((v1_4 != null) && (v1_4.close)) {
                try {
                    io.sqlc.SQLitePlugin.access$200(this.this$0, this.dbname);
                    io.sqlc.SQLitePlugin.access$100(this.this$0).remove(this.dbname);
                } catch (org.apache.cordova.CallbackContext v0_6) {
                    android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t close database", v0_6);
                    if (v1_4.cbc != null) {
                        org.apache.cordova.CallbackContext v1_6 = v1_4.cbc;
                        String v2_31 = new StringBuilder();
                        v2_31.append("couldn\'t close database: ");
                        v2_31.append(v0_6);
                        v1_6.error(v2_31.toString());
                    }
                }
                if (v1_4.delete) {
                    try {
                        if (!io.sqlc.SQLitePlugin.access$300(this.this$0, this.dbname)) {
                            v1_4.cbc.error("couldn\'t delete database");
                        } else {
                            v1_4.cbc.success();
                        }
                    } catch (String v2_25) {
                        android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t delete database", v2_25);
                        org.apache.cordova.CallbackContext v0_5 = v1_4.cbc;
                        StringBuilder v3_13 = new StringBuilder();
                        v3_13.append("couldn\'t delete database: ");
                        v3_13.append(v2_25);
                        v0_5.error(v3_13.toString());
                    }
                } else {
                    v1_4.cbc.success();
                }
            }
            return;
        } catch (org.apache.cordova.CallbackContext v0_7) {
            android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "unexpected error, stopping db thread", v0_7);
            io.sqlc.SQLitePlugin.access$100(this.this$0).remove(this.dbname);
            return;
        }
    }
}
