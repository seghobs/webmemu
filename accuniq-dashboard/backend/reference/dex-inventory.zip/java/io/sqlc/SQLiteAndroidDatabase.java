package io.sqlc;
 class SQLiteAndroidDatabase {
    private static final java.util.regex.Pattern DELETE_TABLE_NAME;
    private static final java.util.regex.Pattern FIRST_WORD;
    private static final java.util.regex.Pattern UPDATE_TABLE_NAME;
    private static final java.util.regex.Pattern WHERE_CLAUSE;
    private static final boolean isPostHoneycomb;
    java.io.File dbFile;
    boolean isTransactionActive;
    android.database.sqlite.SQLiteDatabase mydb;

    static SQLiteAndroidDatabase()
    {
        int v0_5;
        io.sqlc.SQLiteAndroidDatabase.FIRST_WORD = java.util.regex.Pattern.compile("^[\\s;]*([^\\s;]+)", 2);
        io.sqlc.SQLiteAndroidDatabase.WHERE_CLAUSE = java.util.regex.Pattern.compile("\\s+WHERE\\s+(.+)$", 2);
        io.sqlc.SQLiteAndroidDatabase.UPDATE_TABLE_NAME = java.util.regex.Pattern.compile("^\\s*UPDATE\\s+(\\S+)", 2);
        io.sqlc.SQLiteAndroidDatabase.DELETE_TABLE_NAME = java.util.regex.Pattern.compile("^\\s*DELETE\\s+FROM\\s+(\\S+)", 2);
        if (android.os.Build$VERSION.SDK_INT < 11) {
            v0_5 = 0;
        } else {
            v0_5 = 1;
        }
        io.sqlc.SQLiteAndroidDatabase.isPostHoneycomb = v0_5;
        return;
    }

    SQLiteAndroidDatabase()
    {
        this.isTransactionActive = 0;
        return;
    }

    private void bindArgsToStatement(android.database.sqlite.SQLiteStatement p5, org.json.JSONArray p6)
    {
        int v0 = 0;
        while (v0 < p6.length()) {
            if ((!(p6.get(v0) instanceof Float)) && (!(p6.get(v0) instanceof Double))) {
                if (!(p6.get(v0) instanceof Number)) {
                    if (!p6.isNull(v0)) {
                        p5.bindString((v0 + 1), p6.getString(v0));
                    } else {
                        p5.bindNull((v0 + 1));
                    }
                } else {
                    p5.bindLong((v0 + 1), p6.getLong(v0));
                }
            } else {
                p5.bindDouble((v0 + 1), p6.getDouble(v0));
            }
            v0++;
        }
        return;
    }

    private void bindPostHoneycomb(org.json.JSONObject p3, String p4, android.database.Cursor p5, int p6)
    {
        int v0 = p5.getType(p6);
        if (v0 == 0) {
            p3.put(p4, org.json.JSONObject.NULL);
        } else {
            if (v0 == 1) {
                p3.put(p4, p5.getLong(p6));
            } else {
                if (v0 == 2) {
                    p3.put(p4, p5.getDouble(p6));
                } else {
                    p3.put(p4, p5.getString(p6));
                }
            }
        }
        return;
    }

    private final int countRowsAffectedCompat(io.sqlc.SQLiteAndroidDatabase$QueryType p10, String p11, org.json.JSONArray p12, android.database.sqlite.SQLiteDatabase p13)
    {
        org.json.JSONArray v1_4 = io.sqlc.SQLiteAndroidDatabase.WHERE_CLAUSE.matcher(p11);
        String v3_0 = "";
        int v4_1 = 0;
        while (v1_4.find(v4_1)) {
            String v3_2 = new StringBuilder();
            v3_2.append(" WHERE ");
            v3_2.append(v1_4.group(1));
            v3_0 = v3_2.toString();
            v4_1 = v1_4.start(1);
        }
        org.json.JSONArray v1_1 = 0;
        int v4_2 = 0;
        while (v1_1 < v3_0.length()) {
            if (v3_0.charAt(v1_1) == 63) {
                v4_2++;
            }
            v1_1++;
        }
        org.json.JSONArray v1_2 = 0;
        if (p12 != null) {
            v1_2 = new org.json.JSONArray();
            String v6_2 = (p12.length() - v4_2);
            int v4_3 = v6_2;
            while (v4_3 < p12.length()) {
                v1_2.put((v4_3 - v6_2), p12.get(v4_3));
                v4_3++;
            }
        }
        if (p10 != io.sqlc.SQLiteAndroidDatabase$QueryType.update) {
            Exception v10_2 = io.sqlc.SQLiteAndroidDatabase.DELETE_TABLE_NAME.matcher(p11);
            if (v10_2.find()) {
                Exception v10_3 = v10_2.group(1);
                try {
                    String v11_3 = new StringBuilder();
                    v11_3.append("SELECT count(*) FROM ");
                    v11_3.append(v10_3);
                    v11_3.append(v3_0);
                    Exception v10_5 = p13.compileStatement(v11_3.toString());
                    this.bindArgsToStatement(v10_5, v1_2);
                    return ((int) v10_5.simpleQueryForLong());
                } catch (Exception v10_7) {
                    android.util.Log.e(io.sqlc.SQLiteAndroidDatabase.getSimpleName(), "uncaught", v10_7);
                }
            }
        } else {
            Exception v10_9 = io.sqlc.SQLiteAndroidDatabase.UPDATE_TABLE_NAME.matcher(p11);
            if (v10_9.find()) {
                Exception v10_10 = v10_9.group(1);
                try {
                    String v11_8 = new StringBuilder();
                    v11_8.append("SELECT count(*) FROM ");
                    v11_8.append(v10_10);
                    v11_8.append(v3_0);
                    Exception v10_12 = p13.compileStatement(v11_8.toString());
                } catch (Exception v10_13) {
                    android.util.Log.e(io.sqlc.SQLiteAndroidDatabase.getSimpleName(), "uncaught", v10_13);
                }
                if (v1_2 != null) {
                    this.bindArgsToStatement(v10_12, v1_2);
                }
                return ((int) v10_12.simpleQueryForLong());
            }
        }
        return 0;
    }

    private void executeSqlBatchStatement(String p22, org.json.JSONArray p23, org.json.JSONArray p24)
    {
        void v1 = this;
        if (this.mydb != null) {
            String v0_0 = "unknown";
            try {
                int v12_0;
                String v10_0;
                int v7_2;
                io.sqlc.SQLiteAndroidDatabase$QueryType v13 = io.sqlc.SQLiteAndroidDatabase.getQueryType(p22);
                try {
                    if ((v13 != io.sqlc.SQLiteAndroidDatabase$QueryType.update) && (v13 != io.sqlc.SQLiteAndroidDatabase$QueryType.delete)) {
                        v7_2 = 1;
                        v10_0 = 0;
                        v12_0 = 0;
                        try {
                            if ((v13 != io.sqlc.SQLiteAndroidDatabase$QueryType.insert) || (p23 == null)) {
                                String v14_1 = "Raw query error=";
                                String v0_1 = v0_0;
                                android.database.sqlite.SQLiteDatabase v4_12;
                                if (v13 != io.sqlc.SQLiteAndroidDatabase$QueryType.begin) {
                                    v4_12 = v7_2;
                                } else {
                                    try {
                                        v1.mydb.beginTransaction();
                                        v1.isTransactionActive = 1;
                                        android.database.sqlite.SQLiteDatabase v4_16 = new org.json.JSONObject();
                                        try {
                                            v4_16.put("rowsAffected", 0);
                                            v10_0 = v4_16;
                                        } catch (String v0_7) {
                                            v10_0 = v4_16;
                                            v0_7.printStackTrace();
                                            v0_1 = v0_7.getMessage();
                                            android.database.sqlite.SQLiteDatabase v4_18 = new StringBuilder();
                                            v4_18.append("SQLiteDatabase.beginTransaction(): Error=");
                                            v4_18.append(v0_1);
                                            android.util.Log.v("executeSqlBatch", v4_18.toString());
                                        } catch (String v0_2) {
                                            v10_0 = v4_16;
                                            int v11_0 = v12_0;
                                            v0_2.printStackTrace();
                                            v0_1 = v0_2.getMessage();
                                            String v2_11 = new StringBuilder();
                                            v2_11.append("SQLiteAndroidDatabase.executeSql[Batch](): Error=");
                                            v2_11.append(v0_1);
                                            android.util.Log.v("executeSqlBatch", v2_11.toString());
                                            v12_0 = v11_0;
                                            if (v10_0 == null) {
                                                String v5_12 = new org.json.JSONObject();
                                                v5_12.put("type", "error");
                                                String v3_5 = new org.json.JSONObject();
                                                v3_5.put("message", v0_1);
                                                v3_5.put("code", v12_0);
                                                v5_12.put("result", v3_5);
                                                p24.put(v5_12);
                                            } else {
                                                try {
                                                    String v0_16 = new org.json.JSONObject();
                                                    v0_16.put("type", "success");
                                                    v0_16.put("result", v10_0);
                                                    p24.put(v0_16);
                                                } catch (String v0_17) {
                                                    v0_17.printStackTrace();
                                                    String v2_16 = new StringBuilder();
                                                    v2_16.append("SQLiteAndroidDatabase.executeSql[Batch](): Error=");
                                                    v2_16.append(v0_17.getMessage());
                                                    android.util.Log.v("executeSqlBatch", v2_16.toString());
                                                }
                                            }
                                            return;
                                        }
                                        v4_12 = 0;
                                    } catch (String v0_7) {
                                    }
                                }
                                try {
                                    String v5_4;
                                    if (v13 == io.sqlc.SQLiteAndroidDatabase$QueryType.commit) {
                                        try {
                                            v1.mydb.setTransactionSuccessful();
                                            v1.mydb.endTransaction();
                                            v1.isTransactionActive = 0;
                                            v5_4 = new org.json.JSONObject();
                                            try {
                                                v5_4.put("rowsAffected", 0);
                                                v10_0 = v5_4;
                                            } catch (String v0_8) {
                                                v10_0 = v5_4;
                                                v0_8.printStackTrace();
                                                v0_1 = v0_8.getMessage();
                                                android.database.sqlite.SQLiteDatabase v4_24 = new StringBuilder();
                                                v4_24.append("SQLiteDatabase.setTransactionSuccessful/endTransaction(): Error=");
                                                v4_24.append(v0_1);
                                                android.util.Log.v("executeSqlBatch", v4_24.toString());
                                            }
                                            v4_12 = 0;
                                        } catch (String v0_8) {
                                        }
                                    }
                                } catch (String v0_2) {
                                    v10_0 = v5_4;
                                }
                                if (v13 == io.sqlc.SQLiteAndroidDatabase$QueryType.rollback) {
                                    try {
                                        v1.mydb.endTransaction();
                                        v4_12 = 0;
                                        try {
                                            v1.isTransactionActive = 0;
                                            v5_4 = new org.json.JSONObject();
                                            try {
                                                v5_4.put("rowsAffected", 0);
                                                v10_0 = v5_4;
                                            } catch (String v0_9) {
                                                v10_0 = v5_4;
                                                v0_9.printStackTrace();
                                                v0_1 = v0_9.getMessage();
                                                String v5_9 = new StringBuilder();
                                                v5_9.append("SQLiteDatabase.endTransaction(): Error=");
                                                v5_9.append(v0_1);
                                                android.util.Log.v("executeSqlBatch", v5_9.toString());
                                            }
                                        } catch (String v0_9) {
                                        }
                                    } catch (String v0_9) {
                                        v4_12 = 0;
                                    }
                                }
                                if (v4_12 == null) {
                                } else {
                                    try {
                                        v10_0 = v1.executeSqlStatementQuery(v1.mydb, p22, p23);
                                    } catch (String v0_10) {
                                        v0_10.printStackTrace();
                                        v0_1 = v0_10.getMessage();
                                        String v2_3 = new StringBuilder();
                                        v2_3.append(v14_1);
                                        v2_3.append(v0_1);
                                        android.util.Log.v("executeSqlBatch", v2_3.toString());
                                    }
                                    v11_0 = v12_0;
                                }
                            } else {
                                int v7_1 = v1.mydb.compileStatement(p22);
                                v1 = v1.bindArgsToStatement(v7_1, p23);
                                v14_1 = "Raw query error=";
                                try {
                                    android.database.sqlite.SQLiteDatabase v4_0 = v7_1.executeInsert();
                                    try {
                                        Exception v18_2;
                                        v10_0 = new org.json.JSONObject();
                                        long v16_1 = v4_0 cmp -1;
                                    } catch (String v0_4) {
                                        v10_0 = v16_1;
                                        v0_4.printStackTrace();
                                        android.database.sqlite.SQLiteDatabase v4_7 = new StringBuilder();
                                        v4_7.append("constraint failure: ");
                                        v4_7.append(v0_4.getMessage());
                                        v0_1 = v4_7.toString();
                                        android.database.sqlite.SQLiteDatabase v4_9 = new StringBuilder();
                                        v4_9.append("SQLiteDatabase.executeInsert(): Error=");
                                        v4_9.append(v0_1);
                                        android.util.Log.v("executeSqlBatch", v4_9.toString());
                                        v12_0 = 6;
                                        v7_1.close();
                                        v7_2 = 0;
                                    } catch (String v0_3) {
                                        v10_0 = v16_1;
                                        v0_3.printStackTrace();
                                        v0_1 = v0_3.getMessage();
                                        android.database.sqlite.SQLiteDatabase v4_4 = new StringBuilder();
                                        v4_4.append("SQLiteDatabase.executeInsert(): Error=");
                                        v4_4.append(v0_1);
                                        android.util.Log.v("executeSqlBatch", v4_4.toString());
                                    } catch (String v0_2) {
                                        v11_0 = v12_0;
                                        v10_0 = v16_1;
                                    }
                                    if (v16_1 == 0) {
                                        v18_2 = v0_0;
                                        v10_0.put("rowsAffected", 0);
                                    } else {
                                        v18_2 = v0_0;
                                        v10_0.put("insertId", v4_0);
                                        v10_0.put("rowsAffected", 1);
                                    }
                                    v0_1 = v18_2;
                                } catch (String v0_3) {
                                }
                            }
                        } catch (String v0_2) {
                        } catch (String v0_2) {
                        }
                    } else {
                        String v14_5 = this.mydb.compileStatement(p22);
                        if (p23 != null) {
                            v1 = this.bindArgsToStatement(v14_5, p23);
                        }
                        try {
                            int v7_3 = v14_5.executeUpdateDelete();
                        } catch (String v0_22) {
                            String v10_4 = v0_22;
                            v10_4.printStackTrace();
                            String v0_24 = new StringBuilder();
                            v0_24.append("constraint failure: ");
                            v0_24.append(v10_4.getMessage());
                            v0_0 = v0_24.toString();
                            try {
                                String v10_7 = new StringBuilder();
                                v10_7.append(v7_3);
                                v10_7.append(v0_0);
                                android.util.Log.v("executeSqlBatch", v10_7.toString());
                                v7_3 = -1;
                                String v10_8 = 6;
                            } catch (String v0_2) {
                                v10_0 = 0;
                            }
                            try {
                                int v12_2;
                                v14_5.close();
                            } catch (String v0_2) {
                                v11_0 = v10_8;
                                v10_0 = 0;
                            }
                            if (v7_3 == -1) {
                                v12_2 = 0;
                            } else {
                                v12_2 = new org.json.JSONObject();
                                try {
                                    v12_2.put("rowsAffected", v7_3);
                                } catch (String v0_2) {
                                    v11_0 = v10_8;
                                    v10_0 = v12_2;
                                }
                            }
                            v7_2 = 0;
                            v12_0 = v10_8;
                            v10_0 = v12_2;
                        } catch (String v0_21) {
                            android.database.sqlite.SQLiteException v17 = v0_21;
                            v17.printStackTrace();
                            v0_0 = v17.getMessage();
                            String v10_3 = new StringBuilder();
                            v10_3.append(v7_3);
                            v10_3.append(v0_0);
                            android.util.Log.v("executeSqlBatch", v10_3.toString());
                            v7_3 = -1;
                        } catch (String v0_13) {
                            String v2_14 = v0_13;
                            v2_14.printStackTrace();
                            String v3_7 = new StringBuilder();
                            v3_7.append("INTERNAL PLUGIN ERROR: could not do myStatement.executeUpdateDelete(): ");
                            v3_7.append(v2_14.getMessage());
                            android.util.Log.v("SQLiteAndroidDatabase.executeSqlBatchStatement", v3_7.toString());
                            throw v2_14;
                        }
                        v10_8 = 0;
                    }
                } catch (String v0_2) {
                    v10_0 = 0;
                    v11_0 = 0;
                }
                v11_0 = 6;
            } catch (String v0_2) {
            }
        } else {
            return;
        }
    }

    private org.json.JSONObject executeSqlStatementQuery(android.database.sqlite.SQLiteDatabase p9, String p10, org.json.JSONArray p11)
    {
        org.json.JSONObject v1_1 = new org.json.JSONObject();
        try {
            Exception v2_8 = new String[p11.length()];
            String v4_8 = 0;
        } catch (android.database.Cursor v9_2) {
            v9_2.printStackTrace();
            org.json.JSONException v10_5 = v9_2.getMessage();
            String v11_4 = new StringBuilder();
            v11_4.append("SQLiteAndroidDatabase.executeSql[Batch](): Error=");
            v11_4.append(v10_5);
            android.util.Log.v("executeSqlBatch", v11_4.toString());
            throw v9_2;
        }
        while (v4_8 < p11.length()) {
            if (!p11.isNull(v4_8)) {
                v2_8[v4_8] = p11.getString(v4_8);
            } else {
                v2_8[v4_8] = "";
            }
            v4_8++;
        }
        android.database.Cursor v9_1 = p9.rawQuery(p10, v2_8);
        if ((v9_1 != null) && (v9_1.moveToFirst())) {
            org.json.JSONException v10_3 = new org.json.JSONArray();
            String v11_1 = v9_1.getColumnCount();
            while(true) {
                Exception v2_1 = new org.json.JSONObject();
                String v4_0 = 0;
                if (v4_0 >= v11_1) {
                    v10_3.put(v2_1);
                } else {
                    try {
                        String v5_0 = v9_1.getColumnName(v4_0);
                    } catch (Exception v2_10) {
                        v2_10.printStackTrace();
                    }
                    if (!io.sqlc.SQLiteAndroidDatabase.isPostHoneycomb) {
                        Exception v2_3 = new StringBuilder();
                        v2_3.append("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: ");
                        v2_3.append(android.os.Build$VERSION.SDK_INT);
                        android.util.Log.v("SQLiteAndroidDatabase.executeSqlStatementQuery", v2_3.toString());
                        String v4_3 = new StringBuilder();
                        v4_3.append("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: ");
                        v4_3.append(android.os.Build$VERSION.SDK_INT);
                        throw new RuntimeException(v4_3.toString());
                    } else {
                        try {
                            this.bindPostHoneycomb(v2_1, v5_0, v9_1, v4_0);
                            v4_0++;
                        } catch (Exception v2_9) {
                            String v4_6 = new StringBuilder();
                            v4_6.append("INTERNAL PLUGIN ERROR: could not bindPostHoneycomb: ");
                            v4_6.append(v2_9.getMessage());
                            android.util.Log.v("SQLiteAndroidDatabase.executeSqlStatementQuery", v4_6.toString());
                            throw v2_9;
                        }
                        while (v4_0 < v11_1) {
                        }
                    }
                }
                if (!v9_1.moveToNext()) {
                    try {
                        v1_1.put("rows", v10_3);
                    } catch (org.json.JSONException v10_4) {
                        v10_4.printStackTrace();
                    }
                }
            }
        }
        if (v9_1 != null) {
            v9_1.close();
        }
        return v1_1;
    }

    static io.sqlc.SQLiteAndroidDatabase$QueryType getQueryType(String p2)
    {
        RuntimeException v2_4 = io.sqlc.SQLiteAndroidDatabase.FIRST_WORD.matcher(p2);
        if (!v2_4.find()) {
            throw new RuntimeException("query not found");
        } else {
            try {
                RuntimeException v2_1 = v2_4.group(1);
            } catch (IllegalArgumentException) {
                return io.sqlc.SQLiteAndroidDatabase$QueryType.other;
            }
            if (v2_1.length() == 0) {
                throw new RuntimeException("query not found");
            } else {
                return io.sqlc.SQLiteAndroidDatabase$QueryType.valueOf(v2_1.toLowerCase(java.util.Locale.ENGLISH));
            }
        }
    }

    void bugWorkaround()
    {
        this.closeDatabaseNow();
        this.open(this.dbFile);
        return;
    }

    void closeDatabaseNow()
    {
        int v0_0 = this.mydb;
        if (v0_0 != 0) {
            if (this.isTransactionActive) {
                try {
                    v0_0.endTransaction();
                } catch (int v0_4) {
                    String v1_3 = new StringBuilder();
                    v1_3.append("INTERNAL PLUGIN ERROR IGNORED: Not able to end active transaction before closing database: ");
                    v1_3.append(v0_4.getMessage());
                    android.util.Log.v("closeDatabaseNow", v1_3.toString());
                    v0_4.printStackTrace();
                }
                this.isTransactionActive = 0;
            }
            this.mydb.close();
            this.mydb = 0;
        }
        return;
    }

    void executeSqlBatch(String[] p6, org.json.JSONArray[] p7, org.apache.cordova.CallbackContext p8)
    {
        if (this.mydb != null) {
            int v0_1 = p6.length;
            org.json.JSONArray v1_1 = new org.json.JSONArray();
            int v2 = 0;
            while (v2 < v0_1) {
                this.executeSqlBatchStatement(p6[v2], p7[v2], v1_1);
                v2++;
            }
            p8.success(v1_1);
            return;
        } else {
            p8.error("INTERNAL PLUGIN ERROR: database not open");
            return;
        }
    }

    void open(java.io.File p3)
    {
        if (!io.sqlc.SQLiteAndroidDatabase.isPostHoneycomb) {
            RuntimeException v3_5 = new StringBuilder();
            v3_5.append("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: ");
            v3_5.append(android.os.Build$VERSION.SDK_INT);
            android.util.Log.v("SQLiteAndroidDatabase.open", v3_5.toString());
            StringBuilder v1_2 = new StringBuilder();
            v1_2.append("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: ");
            v1_2.append(android.os.Build$VERSION.SDK_INT);
            throw new RuntimeException(v1_2.toString());
        } else {
            this.dbFile = p3;
            this.mydb = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(p3, 0);
            return;
        }
    }
}
