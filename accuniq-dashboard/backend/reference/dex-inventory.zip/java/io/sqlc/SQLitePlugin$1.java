package io.sqlc;
synthetic class SQLitePlugin$1 {
    static final synthetic int[] $SwitchMap$io$sqlc$SQLitePlugin$Action;

    static SQLitePlugin$1()
    {
        int[] v0_6 = new int[io.sqlc.SQLitePlugin$Action.values().length];
        io.sqlc.SQLitePlugin$1.$SwitchMap$io$sqlc$SQLitePlugin$Action = v0_6;
        io.sqlc.SQLitePlugin$Action.echoStringValue.ordinal()[int v1_11] = 1;
        io.sqlc.SQLitePlugin$Action.open.ordinal()[int v1_1] = 2;
        io.sqlc.SQLitePlugin$Action.close.ordinal()[int v1_3] = 3;
        io.sqlc.SQLitePlugin$Action.delete.ordinal()[int v1_5] = 4;
        io.sqlc.SQLitePlugin$Action.executeSqlBatch.ordinal()[int v1_7] = 5;
        try {
            io.sqlc.SQLitePlugin$Action.backgroundExecuteSqlBatch.ordinal()[int v1_9] = 6;
        } catch (NoSuchFieldError) {
        }
        return;
    }
}
