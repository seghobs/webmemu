package io.sqlc;
final class SQLitePlugin$DBQuery {
    final org.apache.cordova.CallbackContext cbc;
    final boolean close;
    final boolean delete;
    final org.json.JSONArray[] jsonparams;
    final String[] queries;
    final boolean stop;
    final synthetic io.sqlc.SQLitePlugin this$0;

    SQLitePlugin$DBQuery(io.sqlc.SQLitePlugin p1)
    {
        this.this$0 = p1;
        this.stop = 1;
        this.close = 0;
        this.delete = 0;
        this.queries = 0;
        this.jsonparams = 0;
        this.cbc = 0;
        return;
    }

    SQLitePlugin$DBQuery(io.sqlc.SQLitePlugin p1, boolean p2, org.apache.cordova.CallbackContext p3)
    {
        this.this$0 = p1;
        this.stop = 1;
        this.close = 1;
        this.delete = p2;
        this.queries = 0;
        this.jsonparams = 0;
        this.cbc = p3;
        return;
    }

    SQLitePlugin$DBQuery(io.sqlc.SQLitePlugin p1, String[] p2, org.json.JSONArray[] p3, org.apache.cordova.CallbackContext p4)
    {
        this.this$0 = p1;
        this.stop = 0;
        this.close = 0;
        this.delete = 0;
        this.queries = p2;
        this.jsonparams = p3;
        this.cbc = p4;
        return;
    }
}
