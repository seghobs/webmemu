package io.sqlc;
public class SQLitePlugin extends org.apache.cordova.CordovaPlugin {
    private java.util.Map dbrmap;

    public SQLitePlugin()
    {
        this.dbrmap = new java.util.concurrent.ConcurrentHashMap();
        return;
    }

    static synthetic io.sqlc.SQLiteAndroidDatabase access$000(io.sqlc.SQLitePlugin p0, String p1, org.apache.cordova.CallbackContext p2, boolean p3)
    {
        return p0.openDatabase(p1, p2, p3);
    }

    static synthetic java.util.Map access$100(io.sqlc.SQLitePlugin p0)
    {
        return p0.dbrmap;
    }

    static synthetic void access$200(io.sqlc.SQLitePlugin p0, String p1)
    {
        p0.closeDatabaseNow(p1);
        return;
    }

    static synthetic boolean access$300(io.sqlc.SQLitePlugin p0, String p1)
    {
        return p0.deleteDatabaseNow(p1);
    }

    private void closeDatabase(String p3, org.apache.cordova.CallbackContext p4)
    {
        Exception v3_3 = ((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(p3));
        if (v3_3 == null) {
            if (p4 != null) {
                p4.success();
            }
        } else {
            try {
                v3_3.q.put(new io.sqlc.SQLitePlugin$DBQuery(this, 0, p4));
            } catch (Exception v3_1) {
                if (p4 != null) {
                    String v1_1 = new StringBuilder();
                    v1_1.append("couldn\'t close database");
                    v1_1.append(v3_1);
                    p4.error(v1_1.toString());
                }
                android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t close database", v3_1);
            }
        }
        return;
    }

    private void closeDatabaseNow(String p2)
    {
        io.sqlc.SQLiteAndroidDatabase v2_2 = ((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(p2));
        if (v2_2 != null) {
            io.sqlc.SQLiteAndroidDatabase v2_3 = v2_2.mydb;
            if (v2_3 != null) {
                v2_3.closeDatabaseNow();
            }
        }
        return;
    }

    private void deleteDatabase(String p3, org.apache.cordova.CallbackContext p4)
    {
        String v0_5 = ((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(p3));
        if (v0_5 == null) {
            if (!this.deleteDatabaseNow(p3)) {
                p4.error("couldn\'t delete database");
            } else {
                p4.success();
            }
        } else {
            try {
                v0_5.q.put(new io.sqlc.SQLitePlugin$DBQuery(this, 1, p4));
            } catch (String v3_2) {
                if (p4 != null) {
                    String v1_2 = new StringBuilder();
                    v1_2.append("couldn\'t close database");
                    v1_2.append(v3_2);
                    p4.error(v1_2.toString());
                }
                android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t close database", v3_2);
            }
        }
        return;
    }

    private boolean deleteDatabaseNow(String p3)
    {
        try {
            return this.cordova.getActivity().deleteDatabase(this.cordova.getActivity().getDatabasePath(p3).getAbsolutePath());
        } catch (int v3_2) {
            android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t delete database", v3_2);
            return 0;
        }
    }

    private boolean executeAndPossiblyThrow(io.sqlc.SQLitePlugin$Action p7, org.json.JSONArray p8, org.apache.cordova.CallbackContext p9)
    {
        int v1 = 0;
        switch (io.sqlc.SQLitePlugin$1.$SwitchMap$io$sqlc$SQLitePlugin$Action[p7.ordinal()]) {
            case 1:
                p9.success(p8.getJSONObject(0).getString("value"));
                break;
            case 2:
                String v7_14 = p8.getJSONObject(0);
                this.startDatabase(v7_14.getString("name"), v7_14, p9);
                break;
            case 3:
                this.closeDatabase(p8.getJSONObject(0).getString("path"), p9);
                break;
            case 4:
                this.deleteDatabase(p8.getJSONObject(0).getString("path"), p9);
                break;
            case 5:
            case 6:
                String v7_17 = p8.getJSONObject(0);
                String v8_2 = v7_17.getJSONObject("dbargs").getString("dbname");
                String v7_1 = v7_17.getJSONArray("executes");
                if (!v7_1.isNull(0)) {
                    String v0_4 = v7_1.length();
                    String[] v2 = new String[v0_4];
                    org.json.JSONArray[] v3 = new org.json.JSONArray[v0_4];
                    while (v1 < v0_4) {
                        org.json.JSONArray v4_0 = v7_1.getJSONObject(v1);
                        v2[v1] = v4_0.getString("sql");
                        v3[v1] = v4_0.getJSONArray("params");
                        v1++;
                    }
                    String v7_4 = new io.sqlc.SQLitePlugin$DBQuery(this, v2, v3, p9);
                    String v8_4 = ((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(v8_2));
                    if (v8_4 == null) {
                        p9.error("INTERNAL PLUGIN ERROR: database not open");
                    } else {
                        try {
                            v8_4.q.put(v7_4);
                        } catch (String v7_7) {
                            android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "couldn\'t add to queue", v7_7);
                            p9.error("INTERNAL PLUGIN ERROR: couldn\'t add to queue");
                        }
                    }
                } else {
                    p9.error("INTERNAL PLUGIN ERROR: missing executes list");
                }
                break;
            default:
        }
        return 1;
    }

    private io.sqlc.SQLiteAndroidDatabase openDatabase(String p4, org.apache.cordova.CallbackContext p5, boolean p6)
    {
        try {
            Exception v4_2 = this.cordova.getActivity().getDatabasePath(p4);
        } catch (Exception v4_1) {
            if (p5 != null) {
                io.sqlc.SQLiteConnectorDatabase v6_5 = new StringBuilder();
                v6_5.append("can\'t open database ");
                v6_5.append(v4_1);
                p5.error(v6_5.toString());
            }
            throw v4_1;
        }
        if (!v4_2.exists()) {
            v4_2.getParentFile().mkdirs();
        }
        io.sqlc.SQLiteConnectorDatabase v6_2;
        String v1_1 = new StringBuilder();
        v1_1.append("Open sqlite db: ");
        v1_1.append(v4_2.getAbsolutePath());
        android.util.Log.v("info", v1_1.toString());
        if (p6 == null) {
            v6_2 = new io.sqlc.SQLiteConnectorDatabase();
        } else {
            v6_2 = new io.sqlc.SQLiteAndroidDatabase();
        }
        v6_2.open(v4_2);
        if (p5 != null) {
            p5.success();
        }
        return v6_2;
    }

    private void startDatabase(String p2, org.json.JSONObject p3, org.apache.cordova.CallbackContext p4)
    {
        if (((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(p2)) == null) {
            io.sqlc.SQLitePlugin$DBRunner v0_5 = new io.sqlc.SQLitePlugin$DBRunner(this, p2, p3, p4);
            this.dbrmap.put(p2, v0_5);
            this.cordova.getThreadPool().execute(v0_5);
        } else {
            java.util.Map v3_2 = new StringBuilder();
            v3_2.append("INTERNAL ERROR: database already open for db name: ");
            v3_2.append(p2);
            p4.error(v3_2.toString());
        }
        return;
    }

    public boolean execute(String p4, org.json.JSONArray p5, org.apache.cordova.CallbackContext p6)
    {
        try {
            try {
                return this.executeAndPossiblyThrow(io.sqlc.SQLitePlugin$Action.valueOf(p4), p5, p6);
            } catch (org.json.JSONException v4_2) {
                android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "unexpected error", v4_2);
                return 0;
            }
        } catch (org.json.JSONException v4_4) {
            android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "unexpected error", v4_4);
            return 0;
        }
        return this.executeAndPossiblyThrow(io.sqlc.SQLitePlugin$Action.valueOf(p4), p5, p6);
    }

    public void onDestroy()
    {
        while (!this.dbrmap.isEmpty()) {
            String v0_2 = ((String) this.dbrmap.keySet().iterator().next());
            this.closeDatabaseNow(v0_2);
            try {
                ((io.sqlc.SQLitePlugin$DBRunner) this.dbrmap.get(v0_2)).q.put(new io.sqlc.SQLitePlugin$DBQuery(this));
            } catch (java.util.Map v1_4) {
                android.util.Log.e(io.sqlc.SQLitePlugin.getSimpleName(), "INTERNAL PLUGIN CLEANUP ERROR: could not stop db thread due to exception", v1_4);
            }
            this.dbrmap.remove(v0_2);
        }
        return;
    }
}
