package io.sqlc;
final enum class SQLitePlugin$Action extends java.lang.Enum {
    private static final synthetic io.sqlc.SQLitePlugin$Action[] $VALUES;
    public static final enum io.sqlc.SQLitePlugin$Action backgroundExecuteSqlBatch;
    public static final enum io.sqlc.SQLitePlugin$Action close;
    public static final enum io.sqlc.SQLitePlugin$Action delete;
    public static final enum io.sqlc.SQLitePlugin$Action echoStringValue;
    public static final enum io.sqlc.SQLitePlugin$Action executeSqlBatch;
    public static final enum io.sqlc.SQLitePlugin$Action open;

    static SQLitePlugin$Action()
    {
        io.sqlc.SQLitePlugin$Action v0_1 = new io.sqlc.SQLitePlugin$Action("echoStringValue", 0);
        io.sqlc.SQLitePlugin$Action.echoStringValue = v0_1;
        io.sqlc.SQLitePlugin$Action v1_2 = new io.sqlc.SQLitePlugin$Action("open", 1);
        io.sqlc.SQLitePlugin$Action.open = v1_2;
        io.sqlc.SQLitePlugin$Action v3_1 = new io.sqlc.SQLitePlugin$Action("close", 2);
        io.sqlc.SQLitePlugin$Action.close = v3_1;
        io.sqlc.SQLitePlugin$Action v5_2 = new io.sqlc.SQLitePlugin$Action("delete", 3);
        io.sqlc.SQLitePlugin$Action.delete = v5_2;
        io.sqlc.SQLitePlugin$Action v7_2 = new io.sqlc.SQLitePlugin$Action("executeSqlBatch", 4);
        io.sqlc.SQLitePlugin$Action.executeSqlBatch = v7_2;
        io.sqlc.SQLitePlugin$Action v9_2 = new io.sqlc.SQLitePlugin$Action("backgroundExecuteSqlBatch", 5);
        io.sqlc.SQLitePlugin$Action.backgroundExecuteSqlBatch = v9_2;
        io.sqlc.SQLitePlugin$Action[] v11_2 = new io.sqlc.SQLitePlugin$Action[6];
        v11_2[0] = v0_1;
        v11_2[1] = v1_2;
        v11_2[2] = v3_1;
        v11_2[3] = v5_2;
        v11_2[4] = v7_2;
        v11_2[5] = v9_2;
        io.sqlc.SQLitePlugin$Action.$VALUES = v11_2;
        return;
    }

    private SQLitePlugin$Action(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    public static io.sqlc.SQLitePlugin$Action valueOf(String p1)
    {
        return ((io.sqlc.SQLitePlugin$Action) Enum.valueOf(io.sqlc.SQLitePlugin$Action, p1));
    }

    public static io.sqlc.SQLitePlugin$Action[] values()
    {
        return ((io.sqlc.SQLitePlugin$Action[]) io.sqlc.SQLitePlugin$Action.$VALUES.clone());
    }
}
