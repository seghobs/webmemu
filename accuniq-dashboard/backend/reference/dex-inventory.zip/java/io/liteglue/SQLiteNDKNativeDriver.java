package io.liteglue;
public class SQLiteNDKNativeDriver {
    public static final int SQLC_API_VERSION = 4;
    public static final int SQLC_BLOB = 4;
    public static final int SQLC_FLOAT = 2;
    public static final int SQLC_INTEGER = 1;
    public static final int SQLC_NULL = 5;
    public static final int SQLC_OPEN_CREATE = 4;
    public static final int SQLC_OPEN_FULLMUTEX = 65536;
    public static final int SQLC_OPEN_MEMORY = 128;
    public static final int SQLC_OPEN_NOMUTEX = 32768;
    public static final int SQLC_OPEN_PRIVATECACHE = 262144;
    public static final int SQLC_OPEN_READONLY = 1;
    public static final int SQLC_OPEN_READWRITE = 2;
    public static final int SQLC_OPEN_SHAREDCACHE = 131072;
    public static final int SQLC_OPEN_URI = 64;
    public static final int SQLC_RESULT_ABORT = 4;
    public static final int SQLC_RESULT_CONSTRAINT = 19;
    public static final int SQLC_RESULT_DONE = 101;
    public static final int SQLC_RESULT_ERROR = 1;
    public static final int SQLC_RESULT_INTERNAL = 2;
    public static final int SQLC_RESULT_MISMATCH = 20;
    public static final int SQLC_RESULT_MISUSE = 21;
    public static final int SQLC_RESULT_OK = 0;
    public static final int SQLC_RESULT_PERM = 3;
    public static final int SQLC_RESULT_ROW = 100;
    public static final int SQLC_TEXT = 3;

    public SQLiteNDKNativeDriver()
    {
        return;
    }

    public static native long sqlc_api_db_open();

    public static native int sqlc_api_version_check();

    public static native int sqlc_db_close();

    public static native int sqlc_db_errcode();

    public static native String sqlc_db_errmsg_native();

    public static native long sqlc_db_last_insert_rowid();

    public static native io.liteglue.SQLiteNativeResponse sqlc_db_open();

    public static native io.liteglue.SQLiteNativeResponse sqlc_db_prepare_st();

    public static native int sqlc_db_total_changes();

    public static native String sqlc_errstr_native();

    public static native int sqlc_st_bind_double();

    public static native int sqlc_st_bind_int();

    public static native int sqlc_st_bind_long();

    public static native int sqlc_st_bind_null();

    public static native int sqlc_st_bind_text_native();

    public static native int sqlc_st_column_count();

    public static native double sqlc_st_column_double();

    public static native int sqlc_st_column_int();

    public static native long sqlc_st_column_long();

    public static native String sqlc_st_column_name();

    public static native String sqlc_st_column_text_native();

    public static native int sqlc_st_column_type();

    public static native int sqlc_st_finish();

    public static native int sqlc_st_step();
}
