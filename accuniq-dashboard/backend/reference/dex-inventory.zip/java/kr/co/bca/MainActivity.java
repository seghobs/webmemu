package kr.co.bca;
public class MainActivity extends org.apache.cordova.CordovaActivity {

    public MainActivity()
    {
        return;
    }

    public void onCreate(android.os.Bundle p3)
    {
        super.onCreate(p3);
        int v3_4 = this.getIntent().getExtras();
        if ((v3_4 != 0) && (v3_4.getBoolean("cdvStartInBackground", 0))) {
            this.moveTaskToBack(1);
        }
        this.loadUrl(this.launchUrl);
        return;
    }
}
